function qs = clusterQueueNames(cluster)
% Return cluster queue names

% Copyright 2023 The MathWorks, Inc.

narginchk(0,1)

if nargin==1 && ~isa(cluster,'parallel.cluster.Generic')
    % Running on the desktop
    % Passed in i/p arg, but wasn't cluster object
    error('Must provide a cluster object.')
end

% The plugin scripts are not on the path (needed for
% runSchedulerCommand).  Need to change directories to it first.
% Tried calling feval instead, but
% feval(/very/long/path/to/plugin/scripts/fcn) won't work.
odir = cd(fullfile(cluster.PluginScriptsLocation,"private"));
% Change back to the old directory on cleanup
x = onCleanup(@()cd(odir));

commandToRun = "qmgr -c 'p s' | grep 'create queue' | cut -f 3 -d' ' | sort";
[FAILED, qs] = runSchedulerCommand(cluster, commandToRun);
qs = strtrim(qs);
if FAILED~=false
    error("Failed to get queues: " + qs)
end

qs = strsplit(qs)';

end
