function [uniq_feats, combo_feats] = clusterFeatures(cluster)
% Return features/constraints for Slurm scheduler

% Copyright 2023 The MathWorks, Inc.

narginchk(1,1)

if ~isa(cluster,'parallel.cluster.Generic')
  error('Cluster object must provide.')
end

% The plugin scripts are not on the path (needed for
% runSchedulerCommand).  Need to change directories to it first.
% Tried calling feval instead, but
% feval(/very/long/path/to/plugin/scripts/fcn) won't work.
odir = cd(fullfile(cluster.PluginScriptsLocation,"private"));
% Change back to the old directory on cleanup
x = onCleanup(@()cd(odir));

% Get list of features that can work together.  For example, if a user
% requests an "EPYC", it wouldn't also make sense to request "E5-2640".
commandToRun = sprintf("pbsnodes -a | grep -oP 'properties = \\K[^ ]+' | tr ',' '\n' | sort -u");
[FAILED, uniq_feats] = runSchedulerCommand(cluster, commandToRun);
uniq_feats = strtrim(uniq_feats);
if FAILED~=false
    error("Failed to get features: " + uniqu_feats)
end
uniq_feats = strsplit(uniq_feats)';

% Get list of unique features
commandToRun = sprintf("pbsnodes -a | grep -oP 'properties = \\K[^ ]+' | sort -u");
[FAILED, combo_feats] = runSchedulerCommand(cluster, commandToRun);
combo_feats = strtrim(combo_feats);
if FAILED~=false
    error("Failed to get features: " + combo_feats)
end

end
